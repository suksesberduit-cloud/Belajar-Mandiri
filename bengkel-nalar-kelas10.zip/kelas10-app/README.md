# Bengkel Nalar — Kelas X

PWA ringkasan belajar Kelas X (Matematika, Fisika, Kimia, Biologi) dengan gaya "buku catatan investigasi seorang penemu": tiap subbab dibedah lewat 7 tahap — Mengamati → Kenapa Ini Ada → Menelaah/Hakikat → Rumus Ditemukan → Di Dunia Nyata → Kasus (contoh soal terpandu) → Uji Nalar (latihan mandiri).

## Status konten

**Semua bab sudah lengkap** untuk keempat mata pelajaran (Matematika 9 bab, Fisika 10 bab, Kimia 10 bab, Biologi 9 bab) — total ±99 subbab, tiap subbab lengkap 7 tahap (Mengamati → Kenapa Ini Ada → Menelaah/Hakikat → Rumus Ditemukan → Di Dunia Nyata → Kasus → Uji Nalar/kuis).

## 1. Coba dulu di browser (sebelum deploy)

Buka `index.html` langsung di browser, atau jalankan server lokal sederhana:

```
python3 -m http.server 8080
```

lalu buka `http://localhost:8080`.

## 2. Deploy sebagai situs (GitHub Pages) + generate APK

1. Buat repo GitHub baru (misalnya `bengkel-nalar`), lalu push semua isi folder ini ke branch `main`.
2. Di repo → **Settings → Pages** → Source: pilih **GitHub Actions**.
3. Buka `twa-manifest.json`, ganti semua `REPLACE-WITH-USERNAME` dengan username/organisasi GitHub kamu, dan sesuaikan path `bengkel-nalar` kalau nama repo berbeda (harus konsisten dengan `host`, `startUrl`, `iconUrl`, `webManifestUrl`, `fullScopeUrl`).
4. Push ke `main`. Tab **Actions** akan otomatis menjalankan workflow **Deploy PWA & Build APK** — dua job berurutan:
   - `deploy-pages`: menerbitkan situsnya ke GitHub Pages.
   - `build-apk`: memasang JDK 17 + Android SDK, lalu membangun APK lewat Bubblewrap dari `twa-manifest.json`.

   Kalau kamu belum menambahkan secret keystore (langkah 5 di bawah), workflow tetap jalan — ia otomatis membuat keystore sekali pakai untuk build itu saja (ada peringatan kuning di log Actions untuk mengingatkan ini).
5. Ambil hasilnya di tab **Actions** → pilih run terakhir → bagian **Artifacts**:
   - `BengkelNalar-apk` → file APK siap diinstall.
   - `signing-keystore-SAVE-ME` → keystore yang dipakai build ini. **Unduh & simpan sekali** kalau kamu belum punya keystore permanen (lihat langkah 5 di bawah) — supaya update aplikasi berikutnya tetap dikenali Android sebagai app yang sama, bukan dianggap app baru.
6. Install APK di Android (aktifkan "Install dari sumber tidak dikenal" jika diminta).

### (Sangat disarankan) Pakai keystore permanen, bukan yang sekali pakai

Tanpa keystore permanen, tiap build ditandatangani dengan kunci berbeda — HP akan menolak meng-update APK lama dengan yang baru (harus uninstall dulu). Untuk menghindari ini, buat keystore SEKALI di komputer lokal kamu:

```
keytool -genkeypair -v -keystore android.keystore -alias bengkelnalar \
  -keyalg RSA -keysize 2048 -validity 10000
```

lalu encode ke base64:

```
base64 -w0 android.keystore > keystore.b64
```

Tambahkan di repo → **Settings → Secrets and variables → Actions** → New repository secret:
- `KEYSTORE_BASE64` — isi file `keystore.b64`
- `KEYSTORE_PASSWORD` — password yang kamu ketik saat `keytool` tadi
- `KEY_PASSWORD` — biasanya sama dengan `KEYSTORE_PASSWORD` kecuali diatur beda

Setelah secret ini ada, workflow otomatis memakainya di setiap build berikutnya — tidak perlu diubah apa-apa lagi di kode.

## Struktur file

```
index.html              shell aplikasi + navigasi tab
style.css                tema "blueprint" (biru cetak biru + garis grid)
app.js                    logika render, progres, drawer daftar bab
content-matematika.js     data materi Matematika
content-fisika.js         data materi Fisika
content-kimia.js          data materi Kimia
content-biologi.js        data materi Biologi
manifest.json             manifest PWA
sw.js                      service worker (mode offline)
twa-manifest.json         konfigurasi Bubblewrap untuk build APK
.github/workflows/        pipeline deploy + build APK
icons/                     ikon aplikasi
```

## Progres belajar

Tombol "Tandai Kasus Ini Selesai" di tiap subbab disimpan di `localStorage` HP masing-masing pengguna (bukan server) — tiap install/HP punya progresnya sendiri.
